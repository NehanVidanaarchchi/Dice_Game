package com.example.coursework
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.TextView

import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val newGame = findViewById<Button>(R.id.btnNewGame)
        val about = findViewById<Button>(R.id.btnAbout)


        val humanWinsCount = intent.getIntExtra("totalHumanWins",0)
        val computerWinsCount = intent.getIntExtra("totalComputerWins",0)

        //new game button
        newGame.setOnClickListener {
            val intent = Intent(this,MainPage::class.java)
            intent.putExtra("humanWinsCount",humanWinsCount)
            intent.putExtra("computerWinsCount",computerWinsCount)
            startActivity(intent)
        }

        //about button
        about.setOnClickListener {

            //About page details
            val name = "Name : Nehan Pavindya"
            val studentId = "Student Id : 20210135 / W1912806"
            val description = "I confirm that I understand what plagiarism is and have read and " +
                    "understood the section on Assessment Offences in the Essential Information for " +
                    "Students. The work that I have submitted is entirely my own. Any work from other " +
                    "authors is duly referenced and acknowledged."
            val message = name +"\n"+studentId+"\n"+ "\n"+description

            //set title to the center
            val title = TextView(this)
            title.setText(R.string.Details)
            title.gravity = Gravity.CENTER
            title.textSize = 20f
            title.setTextColor(Color.BLACK)
            title.setTypeface(null,Typeface.BOLD)

            val aboutPopup = AlertDialog.Builder(this)
            aboutPopup.setCustomTitle(title)
            aboutPopup.setMessage(message)
            val aboutDialog = aboutPopup.create()
            aboutDialog.show()

            // Set the background color of the dialog
            val aboutWindow = aboutDialog.window
            aboutWindow?.setBackgroundDrawable(ColorDrawable(Color.LTGRAY))
        }

    }

}